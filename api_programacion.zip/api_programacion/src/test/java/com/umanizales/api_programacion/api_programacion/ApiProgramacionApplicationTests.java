package com.umanizales.api_programacion.api_programacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProgramacionApplicationTests {

    @Test
    void contextLoads() {
    }

}
