package com.umanizales.api_programacion.api_programacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiProgramacionApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiProgramacionApplication.class, args);
    }

}
