package com.umanizales.api_programacion.api_programacion.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ListSE {
    private Node head;

    private int size;

/// #0 = Contar
    public int count() {
        if (head == null) {
            return 0;
        }
        Node temp = head;
        int counter = 1;
        while (temp.getNext() != null) {
            counter += 1;
            temp = temp.getNext();
        }
        return counter;
    }

/// #1 = Adicionar al final
    public void add(Kid kid) {
        if (head == null) {
            head = new Node(kid);
        } else {
            Node temp = head;
            while (temp.getNext() != null) {
                temp = temp.getNext();
            }
            ///Ayudante está en el último
            Node newNode = new Node(kid);
            temp.setNext(newNode);
        }
    }

/// #2 = Adicionar al inicio
    public void addToStart(Kid kid) {
        if (head == null) {
            head = new Node(kid);
        } else {
            Node newNode = new Node(kid);
            newNode.setNext(head);
            head = newNode;
        }
    }

/// #3 = Borrar por posición
    public void deleteToPosition(int position)
    {
        if(position==1) {
            head = head.getNext();
        }
        else {
            Node temp = head;
            int count = 1;
            while (temp != null) {
                if (count == position - 1) {
                    temp.setNext(temp.getNext().getNext());
                    break;
                }
                temp = temp.getNext();
                size -= 1;
        }
    }
}

/// #4 = Borrar por dato
    public void deleteByData(String data)
    {
        if (head.getData().getIdentification().compareTo(data) == 0)
        {
            head = head.getNext();
        }
        else {
            Node temp = head;
            while (temp != null)
            {
                if (temp.getNext().getData().getIdentification().compareTo(data) == 0)
                {
                    temp.setNext(temp.getNext().getNext());
                    break;
                }
                temp = temp.getNext();
            }
        }
    }

/// #5 Cambiar extremos
    public void changeFirstLast()
    {
        if (count() > 1)
        {
            Node temp = head;
            Kid temp1 = head.getData();
            while (temp != null)
            {
                if (temp.getNext() == null)
                {
                    head.setData(temp.getData());
                    temp.setData(temp1);
                    break;
                }
                temp = temp.getNext();
            }
        }
    }

/// #6 = Invertir
    public void invert()
    {
        if (head != null)
        {
            ListSE newList = new ListSE();
            Node temp = head;
            while (temp != null)
            {
                newList.addToStart(temp.getData());
                temp = temp.getNext();
            }
            head = newList.head;
        }
    }

/// #7 Mezclar por género
    public void mixByGender()
    {
        if (head != null)
        {
            if (count() > 1)
            {
                ListSE newList = new ListSE();
                Node temp = head;
                while (temp != null)
                {
                    if (temp.getData().getGender() == 'M')
                    {
                        newList.add(temp.getData());
                    }
                    else
                    {
                        newList.addToStart(temp.getData());
                    }
                    temp = temp.getNext();
                }
                this.head=newList.head;
            }
        }
    }

/// #8 = Adicionar por posición
    public void addToPosition(int position, Kid kid)
    {
        if (head != null){
            head = new Node(kid);
        }

            if (position==1) {
            ///head = head.getNext();
        }
                else {
                    Node temp = head;
                    int count = 1;
                    while (temp != null) {
                        if (count == position - 1) {

                            break;
                        }
                        temp = temp.getNext();
            }
        }
    }
}