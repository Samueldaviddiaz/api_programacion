package com.umanizales.api_programacion.api_programacion.service;
import com.umanizales.api_programacion.api_programacion.model.Kid;
import com.umanizales.api_programacion.api_programacion.model.ListDE;
import com.umanizales.api_programacion.api_programacion.model.Kid;
import com.umanizales.api_programacion.api_programacion.model.Node;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@NoArgsConstructor
public class ListDEService {
    private ListDE list= new ListDE();

    public Node getAllLinked(){
        return this.list.enlist();
    }
    public String add(Kid kid){
        this.list.add(kid);
        return "Adicionado con exito";
    }
    public String addToStart(Kid kid){
        this.list.addToStart(kid);
        return "Adicionado con éxito";
    }

    public String invert()
    {
        try {
            this.list.invert();
            return "Invertido con éxito.";
        }
        catch (Exception e)
        {
            return e.getMessage();
        }
    }
}
