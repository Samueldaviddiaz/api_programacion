package com.umanizales.api_programacion.api_programacion.model;

import lombok.Data;

@Data
public class ListDE {
    private NodeDE head;
    private int count;

    public Node enlist(){
        ListSE list=new ListSE();
        if(this.head!=null){
            NodeDE temp= this.head;
            while (temp!= null){
                list.add(temp.getData());
                temp= temp.getNext();
            }
        }
        return list.getHead();

    }
    public void add(Kid kid){
        if(this.head==null){
            NodeDE newNode = new NodeDE(kid);
            this.head= newNode;
        }
        else{
            NodeDE temp= this.head;
            while (temp.getNext()!=null){
                temp= temp.getNext();
            }
            NodeDE newNode =new NodeDE(kid);
            temp.setNext(newNode);
            newNode.setPrevious(temp);
        }
        this.count++;
    }
    public void addToStart(Kid kid){
        NodeDE newNode = new NodeDE(kid);
        if (this.head != null) {
            newNode.setNext(this.head);
            this.head.setPrevious(newNode);
        }
        this.head = newNode;
        this.count++;
    }
    public void invert()throws Exception{
        if (this.count >1) {
            ListDE new_list = new ListDE();
            NodeDE temp = this.head;
            while (temp != null) {
                new_list.addToStart(temp.getData());
                temp = temp.getNext();
            }
            this.head = new_list.head;
        }
    }

}