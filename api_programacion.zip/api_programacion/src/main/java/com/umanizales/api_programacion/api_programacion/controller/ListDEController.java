package com.umanizales.api_programacion.api_programacion.controller;
import com.umanizales.api_programacion.api_programacion.model.Kid;
import com.umanizales.api_programacion.api_programacion.model.Node;
import com.umanizales.api_programacion.api_programacion.service.ListDEService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/listde")
public class ListDEController {
    @Autowired
    private ListDEService listDEService;

    @GetMapping
    public Node getAllLinked() {
        return listDEService.getAllLinked();
    }

    @PostMapping
    public String createKid(@RequestBody Kid kid) {
        return listDEService.add(kid);
    }

    @PostMapping(path = "/tostart")
    public String createKidToStart(@RequestBody Kid kid) {
        return listDEService.addToStart(kid);
    }

    @GetMapping(path = "/invert")
    public String invertList() {
        return listDEService.invert();
    }
}
